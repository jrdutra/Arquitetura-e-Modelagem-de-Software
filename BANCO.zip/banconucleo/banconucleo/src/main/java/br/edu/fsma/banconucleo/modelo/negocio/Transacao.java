package br.edu.fsma.banconucleo.modelo.negocio;

public interface Transacao {

	public Double processarTransacao(Double valor);
	
}
