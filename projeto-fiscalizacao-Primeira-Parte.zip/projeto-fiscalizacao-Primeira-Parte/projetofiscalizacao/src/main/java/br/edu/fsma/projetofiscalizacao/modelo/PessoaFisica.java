package br.edu.fsma.projetofiscalizacao.modelo;

public class PessoaFisica {

}
